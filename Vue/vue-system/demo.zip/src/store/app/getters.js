export const version = state => {
  return state.version
}
export const testAjax = state => {
  return state.testAjax
}
