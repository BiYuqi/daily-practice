export const VERSION = 'VERSION'
export const TEST_AJAX = 'TEST_AJAX'
